﻿using System;
using System.Collections.Generic;
using System.IO;
using log4net.Appender.Loki.Labels;
using log4net.Core;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

namespace log4net.Appender.Loki {
    public class LokiAppender : BufferingForwardingAppender {
        private LokiHttpClient _client;
        private readonly IList<LokiLabel> _labels = new List<LokiLabel>();

        public string ServiceUrl { get; set; }
        public string BasicAuthUserName { get; set; }
        public string BasicAuthPassword { get; set; }
        public bool TrustSelfCignedCerts { get; set; } = false;

        /// <summary>
        /// This method is called by log4net to add a label from the config.
        /// </summary>
        public void AddLabel(LokiLabel label) {
            _labels.Add(label);
        }

        public override void ActivateOptions() {
            base.ActivateOptions();

            _client = new LokiHttpClient(TrustSelfCignedCerts);

            if (!string.IsNullOrEmpty(BasicAuthUserName) && !string.IsNullOrEmpty(BasicAuthPassword)) {
                var credentials = new BasicAuthCredentials(ServiceUrl, BasicAuthUserName, BasicAuthPassword);
                _client.SetAuthCredentials(credentials);
            }
        }

        protected override void SendBuffer(LoggingEvent[] events) {
            if (events == null || events.Length == 0) return;

            try {
                var formatter = new LokiBatchFormatter(_labels);
                using (var writer = new StringWriter()) {
                    formatter.Format(events, writer);
                    string json = writer.ToString();

                    if (!string.IsNullOrWhiteSpace(json)) {
                        string requestUri = LokiRouteBuilder.BuildPostUri(ServiceUrl);
                        var postTask = _client.PostAsync(requestUri, json);

                        // Wait for the task to complete synchronously
                        postTask.Wait(TimeSpan.FromSeconds(10));
                    }
                }
            }
            catch (Exception ex) {
                ErrorHandler.Error("Unable to send logs to Loki", ex);
            }
        }

        protected override void OnClose() {
            base.OnClose();
            _client?.Dispose();
        }
    }
}


namespace log4net.Appender.Loki {
    /// <summary>
    /// Builds the URI for posting data to the Loki server.
    /// </summary>
    public static class LokiRouteBuilder {
        // UPDATED URI
        public const string PostDataUri = "/loki/api/v1/push";

        public static string BuildPostUri(string host) {
            return host.TrimEnd('/') + PostDataUri;
        }
    }

    /// <summary>
    /// An HTTP client for sending logs to Loki.
    /// </summary>
    public class LokiHttpClient : IDisposable {
        protected readonly WebClient WebClient;
        private bool _disposed = false;

        public LokiHttpClient(bool trustSelfSignedCerts) {
            WebClient = new WebClient();
            WebClient.Headers[HttpRequestHeader.ContentType] = "application/json";

            if (trustSelfSignedCerts) {
                ServicePointManager.ServerCertificateValidationCallback =
                    (sender, certificate, chain, policyErrors) => true;
            }
        }

        public void SetAuthCredentials(LokiCredentials credentials) {
            if (credentials is BasicAuthCredentials c) {
                var token = Base64Encode($"{c.Username}:{c.Password}");
                WebClient.Headers[HttpRequestHeader.Authorization] = "Basic " + token;
            }
        }

        public virtual Task<string> PostAsync(string requestUri, string jsonContent) {
            return WebClient.UploadStringTaskAsync(new Uri(requestUri), "POST", jsonContent);
        }

        public virtual void Dispose() {
            if (!_disposed) {
                WebClient?.Dispose();
                _disposed = true;
            }
        }

        private static string Base64Encode(string plainText) {
            var plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            return Convert.ToBase64String(plainTextBytes);
        }
    }

    #region Credentials

    public abstract class LokiCredentials {
        public string Url { get; protected set; }
    }

    public class BasicAuthCredentials : LokiCredentials {
        public BasicAuthCredentials(string url, string username, string password) {
            Url = url;
            Username = username;
            Password = password;
        }

        public string Username { get; }
        public string Password { get; }
    }

    #endregion
}


namespace log4net.Appender.Loki {
    /// <summary>
    /// Represents the top-level content object for a Loki push request.
    /// </summary>
    internal class LokiContent {
        public LokiContent() {
            Streams = new List<LokiStream>();
        }

        public List<LokiStream> Streams { get; set; }

        public string Serialize() {
            var sb = new StringBuilder();
            sb.Append("{\"streams\":[");

            for (int i = 0; i < Streams.Count; i++) {
                var stream = Streams[i];
                if (i > 0) sb.Append(",");

                sb.Append("{\"stream\":{");
                // Serialize stream labels
                bool firstLabel = true;
                foreach (var label in stream.Stream) {
                    if (!firstLabel) sb.Append(",");
                    sb.Append("\"").Append(JsonEscape(label.Key)).Append("\":\"").Append(JsonEscape(label.Value))
                        .Append("\"");
                    firstLabel = false;
                }

                sb.Append("},\"values\":[");

                // Serialize values
                for (int j = 0; j < stream.Values.Count; j++) {
                    var val = stream.Values[j];
                    if (j > 0) sb.Append(",");
                    // val[0] is timestamp, val[1] is the log line
                    sb.Append("[\"").Append(val[0]).Append("\",\"").Append(JsonEscape(val[1])).Append("\"]");
                }

                sb.Append("]}");
            }

            sb.Append("]}");
            return sb.ToString();
        }

        private string JsonEscape(string str) {
            if (str == null) return string.Empty;
            return str.Replace("\\", "\\\\")
                .Replace("\"", "\\\"")
                .Replace("\n", "\\n")
                .Replace("\r", "\\r")
                .Replace("\t", "\\t");
        }
    }

    /// <summary>
    /// Represents a stream of log entries with associated labels.
    /// </summary>
    internal class LokiStream {
        public LokiStream() {
            Stream = new Dictionary<string, string>();
            Values = new List<string[]>();
        }

        // "stream": { "label1": "value1", "label2": "value2" }
        public Dictionary<string, string> Stream { get; set; }

        // "values": [ [ "timestamp", "log line" ], [ "timestamp", "log line" ] ]
        public List<string[]> Values { get; set; }
    }
}


namespace log4net.Appender.Loki {
    internal class LokiBatchFormatter {
        private readonly IList<LokiLabel> _globalLabels;
        private static readonly long UnixEpochTicks = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).Ticks;

        public LokiBatchFormatter(IList<LokiLabel> globalLabels) {
            _globalLabels = globalLabels ?? new List<LokiLabel>();
        }

        public void Format(IEnumerable<LoggingEvent> logEvents, TextWriter output) {
            var logs = logEvents.ToList();
            if (!logs.Any()) return;

            var content = new LokiContent();
            var stream = new LokiStream();

            // Add global labels from config
            foreach (var label in _globalLabels) {
                stream.Stream[label.Key] = label.Value;
            }

            // Add all log entries to this single stream
            foreach (var logEvent in logs) {
                // Add level as a default label if not already present
                if (!stream.Stream.ContainsKey("level")) {
                    stream.Stream["level"] = GetLevel(logEvent.Level);
                }

                // Loki timestamp is Unix Epoch in nanoseconds
                long timestamp = (logEvent.TimeStamp.ToUniversalTime().Ticks - UnixEpochTicks) * 100;

                var messageBuilder = new StringBuilder();
                messageBuilder.Append(logEvent.RenderedMessage);
                if (logEvent.ExceptionObject != null) {
                    messageBuilder.AppendLine().Append(logEvent.GetExceptionString());
                }

                stream.Values.Add(new[] {
                    timestamp.ToString(), messageBuilder.ToString()
                });
            }

            if (stream.Values.Any()) {
                content.Streams.Add(stream);
                output.Write(content.Serialize());
            }
        }

        private static string GetLevel(Level level) {
            if (level == null) return "unknown";
            if (level.Value >= Level.Error.Value) return "error";
            if (level.Value >= Level.Warn.Value) return "warning";
            if (level.Value >= Level.Info.Value) return "info";
            return "debug";
        }
    }
}

namespace log4net.Appender.Loki.Labels {
    /// <summary>
    /// Represents a label (key-value pair) that can be set from the log4net config.
    /// </summary>
    public class LokiLabel {
        public string Key { get; set; }
        public string Value { get; set; }
    }
}